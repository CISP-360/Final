#include <iostream>
#include "AirportApplicationHeader.h"

/*
Emergengy Decisions Menu
*/

// Function for defining the char 'ch', and while the input is not equal to Q
// fun the function display menu, then asking the user what they want to input
// then based on that input, displaying a series of answers
void aircraftChoiceMenu(){
  char ch = ' ';
  while (ch!='Q'){
    displayMenu1();
    ch = inputChoice();
    whatsWrong(ch);
  }
}

// shows the user what options they have to choose from
void displayMenu1(){
  std::cout << std::endl;
  std::cout << "Emergency Decisions Menu \n"<<std::endl;
  std::cout << std::endl;
  std::cout << "Communications Failure : C "<<std::endl;
  std::cout << "Engine Failure         : E "<<std::endl;
  std::cout << "In Flight Icing        : I "<<std::endl;
  std::cout << "Quit                   : Q "<<std::endl;
  std::cout << "Enter your choice      : ";
}

// Asks the user to input specific characters, and if they do not, prompt
// them again to enter the right characters
char inputChoice(){
  char ch = ' ';
  std::cin >> ch;
  ch = toupper(ch);
  while (ch!='C' && ch!='E' && ch!='I' && ch!='Q'){
    std::cout << "\nPlease enter a valid choice "<<std::endl;
    std::cin.clear();
    std::cin.ignore(9999,'\n');
    displayMenu1();
    std::cin >> ch;
    ch = toupper(ch);
  }
  
  return ch;
}

// wtf is this
void display(std::string message){
  std::cout<<message<<std::endl;
}

// function to run certain functions based on user input
void whatsWrong(char aircraftIssue){
  switch(aircraftIssue){
  case 'C':
    comFailure();
    break;
  case 'E':
    
    engineFailure();
    break;
  case 'I':
    inflightIcing(iceAmount());
    break;
  case 'Q':
    quit();
    break;
  }
  
}

// when the user inputs C, display this message
void comFailure(){
  std::cout << "Switch to alternate radio. " << std::endl;
  
}

// Series of functions that run, cumulating as the engine failure function.
// asks the user a series of questions with nestled if statements

// this entire thing is disgusting I know I can organize it better but 
// I am not going to
void engineFailure(){
    
    char answer = ' ';
    checkAirborn(answer);
  
    if (answer == 'Y'){
    checkElectrical(answer);
  
    if (answer == 'Y'){
  checkEngine(answer);
  
  if (answer == 'Y'){
  checkMountains(answer);
  
  if (answer == 'Y'){
  checkNight(answer);
  
  if (answer == 'Y'){
  likeWhatYouSee(answer);
  
  if (answer == 'Y'){
  std::cout << "make emergency landing" << std::endl;
  }
  else{
  std::cout << "turn off landing lights" << std::endl;
  }
  }
  
  else{
  std::cout << "Make emergency landing" << std::endl;
  }
  }
  
  else{
  checkWater(answer);
  
  if (answer == 'Y'){
  std::cout << "inflate your lifevest" << std::endl;
  }
  
  else{
  std::cout << "make emergency landing on a road" << std::endl;
  }
  }
  }
  
 else{
  checkTemperature(answer);
  
  if (answer == 'Y'){
  std::cout << "turn on Carberator Heat" << std::endl;
  }
  
  else{
  std::cout << "switch to other fuel tank" << std::endl;    
  }
 }
  }
  
  else{
  std::cout << "turn on the master switch" << std::endl;
  }
  }
  
  else{
  std::cout << "chill for mechanic" << std::endl;
  }
}

// function to check if you are airborn
void checkAirborn(char &answer){
    std::cout << "are you airborn?: " ;
    std::cin >> answer;
    answer = toupper(answer);
}

// function to check if the electronics are working
void checkElectrical(char &answer){
    std::cout << "is the electrical system working?: ";
    std::cin >> answer;
    answer = toupper(answer);
}

// function to check if engine is running
void checkEngine(char &answer){
    std::cout << "has the engine stopped running?: ";
    std::cin >> answer;
    answer = toupper(answer);
}

// function to check how low temp is
void checkTemperature(char &answer){
    std::cout << "is the temperature outside less than 32 degrees?: ";
    std::cin >> answer;
    answer = toupper(answer);
    
}

// function to see if there are mountains
void checkMountains(char &answer){
    std::cout << "are you over the mountains?: ";
    std::cin >> answer;
    answer = toupper(answer);
}

// function to check if there is water below
void checkWater(char &answer){
    std::cout << "are you over the water?: ";
    std::cin >> answer;
    answer = toupper(answer);
}

// function to see if its night
void checkNight(char &answer){
    std::cout << "is it night time?: ";
    std::cin >> answer;
    answer = toupper(answer);
}

// do you like what you see
void likeWhatYouSee(char &answer){
    std::cout << "do you like what you see?: ";
    std::cin >> answer;
    answer = toupper(answer);
    
}

// function to ask the user how much ice is on their plane, and respond with
// the appropriate answer
void inflightIcing(int iceMM){
    iceInstruction(iceMM);
}

// ask the user how much ice they have on their plane 
int iceAmount(){
    int iceMM;
    std::cout << "Estimate how many mm of ice is on your aircraft: ";
    std::cin >> iceMM;
    std::cin.clear();
    std::cin.ignore(9999,'\n');
    return iceMM;
}

// function to respond to the user depending on how much ice there is
void iceInstruction(int iceMM){
    if(iceMM < 1){
    std::cout << "use 5% power" << std::endl;

    }
    else if(iceMM >= 1 && iceMM <= 5){
    std::cout << "use 20% power" << std::endl;

    }
    else if(iceMM > 5 && iceMM <= 9){
    std::cout << "use 65% power" << std::endl;

    }
    else if(iceMM > 9){
    std::cout << "use 100% power" << std::endl;

    }
}

// end program
void quit(){
  std::cout<<("Good Bye!")<<std::endl;

}

/*
Flight Status Reporter
*/

void flightStatusChoice() {
	char input;
	std::string arrivals = "Arrivals.txt";
	std::string departures = "Departures.txt";
	std::ifstream inFile;


	do {
	    displayMenu2();
		std::cin >> input;
		input = toupper(input);
		// when the input is equal to a or d, open either arrivals or departures.
		switch(input) {
		case 'A': {
		    // function to open the arrials text file
			openFile(arrivals,inFile);
			std::string line; // need this definition as the getline function needs it
			std::cout << "*****************************************************" << std::endl;
			std::cout << "AA Airlines Arrival Information into LAX Los Angeles" << std::endl;
			std::cout << "*****************************************************" << std::endl;
			std::cout << "Flight#  Gate#    Airport        Scheduled  Expected  Delay" << std::endl;
			while (std::getline(inFile, line)) { // read through the first line unto the last line until there is no more data
			    // if there was no while loop, it would only read one line of the text file
				extractFile(line);
			}
			inFile.close();  // Close the file after reading
			break;
		}
		// same as case A but for opening the Departures text file
		case 'D': {
			openFile(departures,inFile);
			std::string line;
			std::cout << "*****************************************************" << std::endl;
			std::cout << "AA Airlines Arrival Information into LAX Los Angeles" << std::endl;
			std::cout << "*****************************************************" << std::endl;
			std::cout << "Flight#  Gate#       Airport     Scheduled  Expected  Delay" << std::endl;
			while (std::getline(inFile, line)) {
				extractFile(line);
			}
			inFile.close();  // Close the file after reading
			break;
		}
		case 'Q':
			std::cout << "thanks for playing";
			break;
		}
		
		} while (input != 'q' && input != 'Q'); // when input is equal to q, stop the while loop
}


// Menu for the flightStatus function
void displayMenu2() {
	std::cout << std::endl;
	std::cout << "Flight Status Reporter Menu \n"<<std::endl;
	std::cout << std::endl;
	std::cout << "Arrivals           : A "<<std::endl;
	std::cout << "Departures         : D "<<std::endl;
	std::cout << "Quit               : Q "<<std::endl;
	std::cout << "Enter your choice  : ";
}

// function to open the file
void openFile(const std::string& fileName, std::ifstream& inFile) {
	inFile.open(fileName);
	if (!inFile) {
		std::cerr << "Error opening file: " << fileName << std::endl;
	}
}

// function to read the file and return it.
std::string readFile(std::ifstream& inFile) {
	std::string line;
	std::getline(inFile, line);
	return line;
}

// function to read the file and store the values in variables
void extractFile(const std::string& line) {
    // define all variables
	std::string flightNumber, gateNumber, sourceAirport;
	int scheduledTime, actualTime, delay;

	// Used to parse the line by space-separated tokens, telling the computer
	// that the space seperator means different variables, commas would be the 
	// tell sign for different variables if you told the istringstream to do it.
	std::istringstream instream(line);


	// Extract data from the line
	instream >> flightNumber >> gateNumber >> sourceAirport >> scheduledTime >> actualTime;
	delay = calculateDelay(scheduledTime, actualTime);
	// Output the extracted data (you can modify this for your own logic)

	std::cout << flightNumber << std::setw(6) 
	          << gateNumber << std::setw(15) 
	          << sourceAirport << std::setw(10)
	          << scheduledTime << std::setw(10) 
	          << actualTime << std::setw(10) 
	          << delay << std::endl;
}

// easy asf, take in the scheduled and delayed time, make them into minutes and hours
// add the hours, multiply by 60 to make into minutes, then add hours and minutes,
// subtract actual time by scheduled time to get a delay

int calculateDelay(int scheduledTime, int actualTime) {
	int scheduledHours = (scheduledTime / 100);
	int actualHours = (actualTime / 100);

	if (scheduledHours == 12) {
		scheduledHours = 0;
	}
	if (actualHours == 12) {
		actualHours = 0;
	}

	int totalScheduled = (scheduledHours * 60) + (scheduledTime % 100);
	int totalActual = (actualHours * 60) + (actualTime % 100);

	return totalActual - totalScheduled;
}

/*
Seat Reservation Menu
*/

// main function, program to display, assign or cancel passengers’ seats in an airplane. 
int seatReservationMain() {
    char seats[ROWS][COLUMNS];
    initializeSeats(seats);
    std::string choice;
    
    // do while loop. run once, then check if a condition is met, if true, run again
    do {
        displayMenu3(); // display options
        std::cin >> choice; // get user choice
        
        // basically a complicated switch statement
        if (choice == "R" || choice == "r") {
            std::string seat;
            std::cout << "Enter seat to reserve (e.g., 1A): ";
            std::cin >> seat;
            int row, column;
            // Check if input is valid and attempt to reserve seat
            if (isValidInput(seat, row, column) && reserveSeat(seats, row, column)) {
                std::cout << "Seat " << seat << " reserved successfully.\n";
            }
        } else if (choice == "C" || choice == "c") {
            std::string seat;
            std::cout << "Enter seat to cancel (e.g., 1A): ";
            std::cin >> seat;
            int row, column;
            // Check if input is valid and attempt to cancel seat
            if (isValidInput(seat, row, column) && cancelSeat(seats, row, column)) {
                std::cout << "Seat " << seat << " canceled successfully.\n";
            }
        } else if (choice == "D" || choice == "d") {
            displaySeats(seats);
        } else if (choice != "Q" && choice != "q") {
            std::cout << "Invalid option, please try again.\n";
        }

    } while (choice != "Q" && choice != "q");
    
    std::cout << "Thank you for using AA Airlines seat management system.\n";
    return 0;
}

// Function to initialize the seats to empty (' ')
void initializeSeats(char seats[ROWS][COLUMNS]) {
    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLUMNS; ++j) {
            seats[i][j] = ' '; // Initialize seats as empty
        }
    }
}

// Function to display the current seat arrangement
void displaySeats(char seats[ROWS][COLUMNS]) {
    std::cout << "  A B C D\n";
    for (int i = 0; i < ROWS; ++i) {
        std::cout << std::setw(2) << (i + 1);
        for (int j = 0; j < COLUMNS; ++j) {
            std::cout << " " << seats[i][j];
        }
        std::cout << std::endl;
    }
}

// Function to reserve a seat if it's available
bool reserveSeat(char seats[ROWS][COLUMNS], int row, int column) {
    if (seats[row][column] == 'X') {
        std::cout << "Seat already taken. Please choose another seat.\n";
        return false;
    }
    seats[row][column] = 'X'; // Mark seat as taken
    return true;
}

// Function to cancel a reservation for a seat
bool cancelSeat(char seats[ROWS][COLUMNS], int row, int column) {
    if (seats[row][column] == ' ') {
        std::cout << "Seat is already empty. No reservation to cancel.\n";
        return false;
    }
    seats[row][column] = ' '; // Mark seat as empty
    return true;
}

// Function to validate user input for seat reservation/cancellation
bool isValidInput(const std::string& input, int& row, int& column) {
    if (input.length() != 2 || !isdigit(input[0]) || !isalpha(input[1])) {
        std::cout << "Invalid input format. Please use format like '1A'.\n";
        return false;
    }
    
    row = input[0] - '1'; // Convert to index
    column = toupper(input[1]) - 'A'; // Convert to index
    
    if (row < 0 || row >= ROWS || column < 0 || column >= COLUMNS) {
        std::cout << "Row must be between 1 and 7, and column must be A, B, C, or D.\n";
        return false;
    }
    
    return true;
}

// Function to display menu options for the user
void displayMenu3() {
    std::cout << "Menu Options:\n";
    std::cout << "R - Reserve Seat\n";
    std::cout << "C - Cancel Seat\n";
    std::cout << "D - Display All Available Seats\n";
    std::cout << "Q - Quit\n";
    std::cout << "Enter your choice: ";
}
